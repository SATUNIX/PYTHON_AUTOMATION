import random

num_words = int(input("How many words? "))
words = []

with open("words.txt", "r") as file:
    for line in file:
        words.append(line.strip())

random_words = random.sample(words, num_words)
result = "/".join(random_words)

print("Result:", result)
